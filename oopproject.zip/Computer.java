package oopproject;

public class Computer extends Product {
	Computer(){super(200);}
	public String toString() {
		return "Computer";
	}
}
