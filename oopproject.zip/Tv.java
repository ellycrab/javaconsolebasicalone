package oopproject;

public class Tv extends Product{
	
	Tv(){
		super(100);
	}
	
	public String toString() {
		return "Tv";
	}

}
