package oopproject;

public class Audio extends Product{
	Audio(){super(50);}
	public String toString() {
		return "Audio";
	}
}
