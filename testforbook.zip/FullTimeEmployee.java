package testforbook;

public class FullTimeEmployee implements Employee, Payable {
    private final String id;
    private final String name;
    private final String dept;
    private final int baseSalary;     // �� �⺻��

    public FullTimeEmployee(String id, String name, String dept, int baseSalary) {
        this.id = id;
        this.name = name;
        this.dept = dept;
        this.baseSalary = baseSalary;
    }

    @Override public String getId()   { return id; }
    @Override public String getName() { return name; }
    @Override public String getDept() { return dept; }

    @Override
    public int calculatePay() {
        return baseSalary;            // ������: �⺻�� �״��
    }

    @Override
    public String toString() { return "FullTime(" + id + "," + name + ")"; }
}
