package testforbook;

public class PartTimeEmployee implements Employee, Payable {
    private final String id;
    private final String name;
    private final String dept;
    private final int hourlyWage;     // �ñ�
    private final int hours;          // �̹� ��(����Ⱓ) �ٷνð�

    public PartTimeEmployee(String id, String name, String dept, int hourlyWage, int hours) {
        this.id = id;
        this.name = name;
        this.dept = dept;
        this.hourlyWage = hourlyWage;
        this.hours = hours;
    }

    @Override public String getId()   { return id; }
    @Override public String getName() { return name; }
    @Override public String getDept() { return dept; }

    @Override
    public int calculatePay() {
        return hourlyWage * hours;    // �˹�: �ñ� * �ð�
    }

    @Override
    public String toString() { return "PartTime(" + id + "," + name + ")"; }
}

