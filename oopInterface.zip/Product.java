package oopInterface;

public interface Product {
	int getPrice();
	int getBonusPoint();
}
