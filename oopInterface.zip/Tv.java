package oopInterface;

public class Tv implements Product{

	private int price;
	private int bonusPoint;
	
	
	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return price;
	}

	@Override
	public int getBonusPoint() {
		// TODO Auto-generated method stub
		return bonusPoint;
	}

}
