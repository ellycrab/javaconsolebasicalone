package oopInterface;

public class Audio implements Product{

	
	private int price;
    private int bonusPoint;
    
    
    public Audio() {
        this(50);
    }

    public Audio(int price) {
        this.price = price;
        this.bonusPoint = (int)(price / 10.0);
    }
	
	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return price;
	}

	@Override
	public int getBonusPoint() {
		// TODO Auto-generated method stub
		return bonusPoint;
	}
	
	@Override
    public String toString() {
        return "Audio";
    }

}
