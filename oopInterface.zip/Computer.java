package oopInterface;

public class Computer implements Product {
    private int price;
    private int bonusPoint;

    public Computer() {
        this(200);
    }

    public Computer(int price) {
        this.price = price;
        this.bonusPoint = (int)(price / 10.0);
    }

    @Override
    public int getPrice() {
        return price;
    }

    @Override
    public int getBonusPoint() {
        return bonusPoint;
    }

    @Override
    public String toString() {
        return "Computer";
    }
}
